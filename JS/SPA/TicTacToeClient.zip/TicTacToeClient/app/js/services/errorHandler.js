app.factory('errorHandler', ['auth', 'notifier',
    function(auth, notifier) {
    return function errorHandler(response){
        if (response.Message == "Authorization has been denied for this request.") {
            auth.logout();
        }
        else {
            notifier.error(response.Message);
        }
    }
}]);

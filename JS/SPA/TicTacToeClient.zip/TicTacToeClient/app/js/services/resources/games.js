'use strict';

app.factory('gamesService', ['$http', '$q', 'identity', 'authorization', 'baseServiceUrl', function($http, $q, identity, authorization, baseServiceUrl) {
    var gamesApi = baseServiceUrl + '/api/games'

    return {
        create: function()
        {
            var headers = authorization.getAuthorizationHeader();
            return $http.post(gamesApi+"/create" , {}, { headers: headers });
        },
        join: function(id)
        {
            var headers = authorization.getAuthorizationHeader();
            return $http.post(gamesApi+"/join?gameId=" +id, {}, { headers: headers });
        },
        list: function() {
           return $http.get(gamesApi , {}, { headers: {"content-type":"application/json" }});
        },
        isAuthenticated: function() {
            if (identity.isAuthenticated()) {
                return true;
            }
            else {
                return $q.reject('not authorized');
            }
        }
    }
}])
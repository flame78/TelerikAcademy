﻿namespace CohesionAndCoupling
{
    using System;

    public class UtilsExamples
    {
        private static void Main()
        {
            Console.WriteLine("example".GetFileExtension());
            Console.WriteLine("example.pdf".GetFileExtension());
            Console.WriteLine("example.new.pdf".GetFileExtension());

            Console.WriteLine("example".GetFileNameWithoutExtension());
            Console.WriteLine("example.pdf".GetFileNameWithoutExtension());
            Console.WriteLine("example.new.pdf".GetFileNameWithoutExtension());

            Console.WriteLine(
                "Distance in the 2D space = {0:f2}",
                MeasurementsOperations.CalcDistance2D(1, -2, 3, 4));

            Console.WriteLine(
                "Distance in the 3D space = {0:f2}",
                MeasurementsOperations.CalcDistance3D(5, 2, -1, 3, -6, 4));

            double width = 3;
            double height = 4;
            double depth = 5;

            Console.WriteLine("Volume = {0:f2}", MeasurementsOperations.CalcVolume(width, height, depth));
            Console.WriteLine("Diagonal XYZ = {0:f2}", MeasurementsOperations.CalcDiagonalXYZ(width, height, depth));
            Console.WriteLine("Diagonal XY = {0:f2}", MeasurementsOperations.CalcDiagonalXY(width, height));
            Console.WriteLine("Diagonal XZ = {0:f2}", MeasurementsOperations.CalcDiagonalXZ(width, depth));
            Console.WriteLine("Diagonal YZ = {0:f2}", MeasurementsOperations.CalcDiagonalYZ(height, depth));
        }
    }
}
